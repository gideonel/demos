# login form validation in javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/LORGGIDEONEL/pen/zYWzBjE](https://codepen.io/LORGGIDEONEL/pen/zYWzBjE).

